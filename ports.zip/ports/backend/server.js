const express = require('express');
const bodyParser = require('body-parser');
const db = require('./database');

const app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// API Endpoints
app.get('/entries', (req, res) => {
    db.query('SELECT * FROM services', (err, results) => {
        if (err) return res.status(500).send(err);
        res.json(results);
    });
});

app.post('/entries', (req, res) => {
    const { dienst, port } = req.body;
    db.query('INSERT INTO services (dienst, port) VALUES (?, ?)', [dienst, port], (err, results) => {
        if (err) return res.status(500).send(err);
        res.status(201).send('Entry added');
    });
});

app.put('/entries/:id', (req, res) => {
    const { dienst, port } = req.body;
    const { id } = req.params;
    db.query('UPDATE services SET dienst = ?, port = ? WHERE id = ?', [dienst, port, id], (err, results) => {
        if (err) return res.status(500).send(err);
        res.send('Entry updated');
    });
});

app.delete('/entries/:id', (req, res) => {
    const { id } = req.params;
    db.query('DELETE FROM services WHERE id = ?', [id], (err, results) => {
        if (err) return res.status(500).send(err);
        res.send('Entry deleted');
    });
});

app.listen(3000, () => {
    console.log('Server is running on port 3000');
});
