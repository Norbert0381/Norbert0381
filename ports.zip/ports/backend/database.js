const mysql = require('mysql2');
const connection = mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
});

connection.connect(err => {
    if (err) throw err;
    console.log('Connected to MySQL');

    // Create table if not exists
    const createTable = `
        CREATE TABLE IF NOT EXISTS services (
            id INT AUTO_INCREMENT PRIMARY KEY,
            dienst VARCHAR(255) NOT NULL,
            port VARCHAR(50) NOT NULL
        )
    `;
    connection.query(createTable, err => {
        if (err) throw err;
    });
});

module.exports = connection;
