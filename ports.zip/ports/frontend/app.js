const form = document.getElementById('entryForm');
const entriesTable = document.getElementById('entriesTable');

// Load entries
function loadEntries() {
    fetch('http://localhost:3000/entries')
        .then(res => res.json())
        .then(data => {
            entriesTable.innerHTML = '';
            data.forEach(entry => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${entry.dienst}</td>
                    <td>${entry.port}</td>
                    <td>
                        <button onclick="deleteEntry(${entry.id})">Löschen</button>
                    </td>
                `;
                entriesTable.appendChild(row);
            });
        });
}

// Add entry
form.addEventListener('submit', e => {
    e.preventDefault();
    const dienst = document.getElementById('dienst').value;
    const port = document.getElementById('port').value;

    fetch('http://localhost:3000/entries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ dienst, port }),
    }).then(() => {
        loadEntries();
        form.reset();
    });
});

// Delete entry
function deleteEntry(id) {
    fetch(`http://localhost:3000/entries/${id}`, {
        method: 'DELETE',
    }).then(() => loadEntries());
}

loadEntries();
